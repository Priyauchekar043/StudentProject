import { DonorLocation } from './donor-location';

describe('DonorLocation', () => {
  it('should create an instance', () => {
    expect(new DonorLocation()).toBeTruthy();
  });
});
