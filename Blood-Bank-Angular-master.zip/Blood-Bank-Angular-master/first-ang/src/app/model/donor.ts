export class Donor {
    name: string;
    phNum: string;
    eMail: string;
    pwd: string;
    rePwd: string;
    bloodGroup: string;
    location: string;
}
