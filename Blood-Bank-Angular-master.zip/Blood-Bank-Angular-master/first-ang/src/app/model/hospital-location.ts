export class HospitalLocation {
    hospitalLat: number;
    hospitalLong: number;
}
