import { Donor } from './donor';

describe('Donor', () => {
  it('should create an instance', () => {
    expect(new Donor()).toBeTruthy();
  });
});
