export class DonorLocation {
    donorLat: number;
    donorLong: number;
}
