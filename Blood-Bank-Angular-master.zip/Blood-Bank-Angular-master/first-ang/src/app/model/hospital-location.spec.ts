import { HospitalLocation } from './hospital-location';

describe('HospitalLocation', () => {
  it('should create an instance', () => {
    expect(new HospitalLocation()).toBeTruthy();
  });
});
