export class Admin {
    adminName: string;
    password: string;
}
