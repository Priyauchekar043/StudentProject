import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class Employee {
	
	@Before("execution(* EmployeeManager.getEmployeeById())")
	public void logBeforeV1(JoinPoint j)
	{
		System.out.println(""+j.getSignature().getName());
	}
	
	
	

}
