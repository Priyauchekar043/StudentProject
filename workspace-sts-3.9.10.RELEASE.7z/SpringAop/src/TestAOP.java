import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class TestAOP {

	@SuppressWarnings("resource")
	public static void main(String[] args)
	{
		//ApplicationContext context = new ClassPathXmlApplicationContext("app.xml");
		//EmployeeManager m = context.getBean(EmployeeManager.class);
		//m.getEmployeeById(1);
		System.out.println("abcd");
		
	}
}
