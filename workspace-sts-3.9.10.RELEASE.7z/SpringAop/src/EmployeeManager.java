import org.aspectj.weaver.ast.And;
import org.springframework.stereotype.Component;

@Component
public class EmployeeManager {
	
	public And getEmployeeById(Integer employeeId)
	{
		System.out.println("sssss");
		return new And(null, null);
	}

}
