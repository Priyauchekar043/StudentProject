
@FunctionalInterface
public interface Employee<Integer> {
	
	
	/*
	 * public void fastwork();
	 * 
	 * 
	 * public static int Abc() { return 0; }
	 * 
	 * 
	 * default void doSomeMoreWork1(){
	 * 
	 * }
	 */
	 Integer process(Integer arg1, Integer arg2);      
	 
	 public static int Abc() { return 0; }
	 

}
