import java.util.function.Supplier;

public class Main {
	
	
	public static void main(String[] args) {
		Employee<Integer> intmul = (i1, i2) -> i1*i2;
		Employee<Integer> intmul1 = (i1, i2) -> i1+i2;
		
		System.out.println(intmul.process(5, 4));
		System.out.println(intmul1.process(5, 4));
		
		  Supplier<Double> randomValue = () -> Math.random(); 
		  
	      
	        System.out.println(randomValue.get()); 
	}

}
