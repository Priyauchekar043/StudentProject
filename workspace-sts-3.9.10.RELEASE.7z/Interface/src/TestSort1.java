
import java.util.*;
import java.util.stream.Collectors;  
public class TestSort1{  
public static void main(String args[]){  
ArrayList<Student> al=new ArrayList<Student>();  
al.add(new Student(101,"Vijay",23));  
al.add(new Student(106,"Ajay",27));  
al.add(new Student(105,"Jai",21)); 
al.add(new Student(103,"Sanjay",27));  
al.add(new Student(107,"Shiva",21)); 
  
//Collections.sort(al); 
List<Student> l2 = al.stream().filter(p->p.name.charAt(0) == 'S').map(p-> p).collect(Collectors.toList());
Student maxAge = l2.stream().max((p1,p2)->p1.age>p2.age? 1:-1).get();
System.out.println("listttt-->>"+maxAge.age);
for(Student ts:l2){  
//System.out.println(ts.rollno+" "+ts.name+" "+ts.age);  

//System.out.println("allll"+ts);
}  
}  
}  