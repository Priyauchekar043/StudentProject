
class Student {  
int rollno;  
String name;  
int age;  
Student(int rollno,String name,int age){  
this.rollno=rollno;  
this.name=name;  
this.age=age;  
}  
  
@Override
public String toString() {
	return "Student [rollno=" + rollno + ", name=" + name + ", age=" + age + "]";
}

	/*
	 * public int compareTo(Student st){ System.out.println("hhhh"+st);
	 * System.out.println("uuu"+this.age); if(age==st.age) return 0; else
	 * if(age>st.age) return 1; else return -1; }
	 */
}  