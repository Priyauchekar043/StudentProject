
public class Employee implements Comparable<Employee> {

	
	private Integer age;
	
	
	
	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	
	
	
	@Override
	public String toString() {
		return "Employee [age=" + age + "]";
	}

	@Override
	public int compareTo(Employee a) {
		
		 return this.age;
	}
	
	public static void main(String[] args) {
		Employee e=new Employee();
		e.setAge(10);
		System.out.println(e);
	}
	

}
