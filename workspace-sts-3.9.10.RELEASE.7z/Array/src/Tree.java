import java.util.TreeSet;

public class Tree {
	
	public static void main(String[] args) {
		
	
	TreeSet<String> al =new TreeSet<>();
	
	
	al.add(null);
	System.out.println(al);
	
	}

}
