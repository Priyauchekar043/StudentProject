import java.util.HashSet;

public class HashsetDemo {

	public static void main(String[] args) {
		
		HashSet h =new HashSet ();
		System.out.println(" inital capacity" +h.size());
		h.add("null");
		System.out.println(h);
		h.add("e");
		System.out.println(h);
		h.add("1");
		System.out.println(h);
		h.add("h");
		System.out.println(h);
		h.remove("h");
		System.out.println(h);
		
		
	   System.out.println("nullrepeat add"	+h.add("null"));
		
		System.out.println("hashcode:-" +h.hashCode());
		
		System.out.println("capacity" +h.size());
		System.out.println("object representation" +h.toString());
		System.out.println("equal:-" +h.equals(h));
		System.out.println("duplicate:-"  +h.add("e"));
		System.out.println("Array:-"  +h.toArray());
		
		
	}
}
