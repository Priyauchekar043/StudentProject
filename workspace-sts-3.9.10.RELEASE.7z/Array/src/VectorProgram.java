import java.util.Vector;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class VectorProgram {

	
	public static void main(String[] args) {
		
		int a;
		Vector v= new Vector();
		System.out.println(v.capacity());
		v.add(null);
		for(int i=0; i<10;i++)
		{
			
			v.addElement(i);
		}
		 System.out.println(v);
		 v.firstElement();
		 System.out.println(v);
		 v.parallelStream().filter(null).collect(Collectors.toList());
		 System.out.println(v);
	}
}
