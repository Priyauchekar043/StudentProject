
public class Array {
	
	 
	public static void main(String[] args) {
		
		int arr[]= {12,56,78,45,34,66,90};
		int minVal= 0;
		int frstVal = 0;
		int lastVal = 0;
		
		
		System.out.println("length'-->>"+  arr.length);
		for(int i=0; i< arr.length; i++)
		{
			for(int j=i; j<=i; j++)
			{
				if (arr.length!= j+1) {
			  System.out.println("i-->"+ i + "j-->>" + j);
			  System.out.println(arr[j]+"-->>arr[j+1]-->>"+ arr[j+1]);
			  System.out.println("arr[j]- arr[j+1]"+ (arr[j]- arr[j+1]));
			  if(minVal > arr[j]- arr[j+1]) {
			  minVal = arr[j]- arr[j+1];
			  frstVal = arr[j];
			  lastVal = arr[j+1];
			  }
				}
			} 
		}
		
		System.out.println("minval-->>"+minVal+"/n frstVal-->> "+ frstVal+"/n lastVal-->> "+ lastVal);
	}

}
