import java.util.Stack;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StackDemo {
	public static void main(String[] args) {
		
		Stack<String> s= new Stack<String>();
		s.add("a");
		System.out.println(s);
		s.push("B");
		System.out.println(s);
		s.push("4");
		System.out.println(s);
		s.pop();
		System.out.println(s.capacity());
		System.out.println(s);
		//s.stream().flatMap(s -> Stream.of(s)).forEach(System.out::println);
		  System.out.println("Does the stack contains "
                  + s.search("4")); 
		
		System.out.println(+s.search("a"));
		
		
	}

}
