import java.util.LinkedHashSet;

public class LinkhashsetDemo {
	
	public static void main(String[] args) {
		
		LinkedHashSet lh = new LinkedHashSet();
		
		lh.add("u");
		System.out.println(""+lh);
		lh.add("null");
		System.out.println(""+lh);
		//lh.addAll(null);
		
		lh.add("p");
		System.out.println(""+lh);
		//lh.clear();
		System.out.println(""+lh);
		//System.out.println("hash"+lh);
		System.out.println("Duplicate"+lh.add("u"));
		
		
		
	}

}
