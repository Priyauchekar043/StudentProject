import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class HasnmapDemo {
	
	private Integer a;
	
	public static void main(String[] args) {
		
		
		Map map = new HashMap();
		
		map.put("1", "priya");
		map.put("2", "Manisha");
		map.put("", "Amuu");
		//map.put("", "abcd");
		 System.out.println("capacity"+map.entrySet());
		 System.out.println("capacity:-"+map.hashCode());
		 System.out.println("capacity"+map.containsKey("1"));
		 
		 System.out.println("capacity"+map.containsValue("adbcd"));
		
		 ConcurrentHashMap<Integer, String> concurrHashMap = new ConcurrentHashMap<>();
		 concurrHashMap.put(1, "A");
	        concurrHashMap.put(2, "B");
	        concurrHashMap.put( 3, "B");
	        concurrHashMap.get(1);
	        
	        Iterator<Integer> itr = concurrHashMap.keySet().iterator();
	        
	        synchronized (concurrHashMap) 
	        {
	            while(itr.hasNext()) {
	                System.out.println(concurrHashMap.get(itr.next()));
	            }
	        }
		
		
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((a == null) ? 0 : a.hashCode());
		System.out.println(""+result);
		return result;
		
		
	}
 
	
	}

