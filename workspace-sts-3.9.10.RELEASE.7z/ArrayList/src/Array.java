import java.util.ArrayList;
import java.util.List;

public class Array {

	public static void main(String[] args) {
		List a= new ArrayList();
		a.add("ABC");
		a.add("BCD");
		a.add(new Employee());
		
		System.out.println("List"+a);
		 
		
	}

	@Override
	public String toString() {
		return "Array [getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}
	
	
	
}
