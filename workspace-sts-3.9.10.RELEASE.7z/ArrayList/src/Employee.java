
public class Employee {
	 int a;

	@Override
	public String toString() {
		return "Employee [a=" + a + "]";
	}
	 

}
