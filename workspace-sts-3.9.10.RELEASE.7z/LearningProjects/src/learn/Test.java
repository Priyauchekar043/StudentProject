package learn;

public class Test {

	public static void main(String[] args) throws CloneNotSupportedException {
		
		Employee emp1 = new Employee("Prathu", new Address("Pune", "Maharashtra"));
		
		Employee emp2 = (Employee) emp1.clone();
		
		
		emp1.setName("abc");
		emp1.getAdd().setCity("ashwini");
		
		System.out.println(emp1);
		System.out.println(emp2);
		
	}

}
