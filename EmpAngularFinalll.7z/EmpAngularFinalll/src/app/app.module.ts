import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { HeaderComponent } from './header/header.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import {Emp} from './model/Emp';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
//search module
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { EmpComponent } from './Emp/Emp.component';

import { ViewProfileComponent } from './view-profile/view-profile.component';
import { AddAdminComponent } from './add-admin/add-admin.component';
import { AdminComponent } from './admin/admin.component';
import { AdminListComponent } from './admin-list/admin-list.component';
import { EditempComponent } from './editemp/editemp.component';
import{ EmpListComponent} from './emp-list/emp-list.component';
import { AdminstaffComponent } from './adminstaff/adminstaff.component';
import { AttendanceComponent } from './attendance/attendance.component';
import { AttendlistComponent } from './attendlist/attendlist.component';
import { ApplyleaveComponent } from './applyleave/applyleave.component';
import { LeavelistComponent } from './leavelist/leavelist.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    WelcomeComponent,
    HeaderComponent,
    EmpComponent,
   
    ViewProfileComponent,
   
    AddAdminComponent,
   
    AdminComponent,
   
    AdminListComponent,
    EditempComponent,
    EmpListComponent,
    AdminstaffComponent,
    AttendanceComponent,
    AttendlistComponent,
    ApplyleaveComponent,
    LeavelistComponent
   
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,
    ReactiveFormsModule,
   BrowserAnimationsModule,
   BsDatepickerModule.forRoot(),
    Ng2SearchPipeModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
