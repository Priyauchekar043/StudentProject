import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AttendlistComponent } from './attendlist.component';

describe('AttendlistComponent', () => {
  let component: AttendlistComponent;
  let fixture: ComponentFixture<AttendlistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AttendlistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AttendlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
