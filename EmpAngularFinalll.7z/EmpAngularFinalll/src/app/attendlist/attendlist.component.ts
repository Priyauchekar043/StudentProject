import { Component, OnInit,Input } from '@angular/core';
import { Attendance } from '../model/attendance';
import { AuthenticationService } from '../authentication.service';
import { Router } from '@angular/router';
import {Emp} from '../model/Emp';
import {AttendService} from '../attend.service';
@Component({
  selector: 'app-attendlist',
  templateUrl: './attendlist.component.html',
  styleUrls: ['./attendlist.component.css']
})
export class AttendlistComponent implements OnInit {

  @Input() attendList: Attendance[];
  AdminstaffFlag : boolean= false;
  EmpFlag : boolean = false;
  attendance:Attendance;

  constructor(private authService : AuthenticationService, private attendService:AttendService,
    private router:Router) { 
    this.authService.getEmpDetail().subscribe(data=>{
      this.attendance=data;
      console.log(data.role);
      if(data.role=='Emp'){
        this.EmpFlag = true;
        this.AdminstaffFlag = false;
      }
      else if(data.role=='Adminstaff'){
        this.AdminstaffFlag = true;
        this.EmpFlag = false;
      }
    })
  }


  ngOnInit() {
  }

}
