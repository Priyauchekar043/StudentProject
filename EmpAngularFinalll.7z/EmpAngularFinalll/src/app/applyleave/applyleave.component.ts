import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import {Leave} from '../model/leave';
import {Moment}from 'moment';
import {LeaveserviceService} from '../leaveservice.service';
import { AuthenticationService } from '../authentication.service';

import { DatePipe } from '@angular/common'
import { Emp } from '../model/Emp';
import { EmpService } from '../Emp.service';
@Component({
  selector: 'app-applyleave',
  templateUrl: './applyleave.component.html',
  styleUrls: ['./applyleave.component.css']
})
export class ApplyleaveComponent implements OnInit {
  submitted = false;
  registerForm1: FormGroup;
  selectedIndex: number;
  datepipe: DatePipe = new DatePipe('en-US');

  minDate:Date
  maxDate:Date
  selected = new FormControl(0);
  leave: Leave = new Leave();
   select:{begin:Moment,end:Moment}
  constructor(private leaveService:LeaveserviceService,private authService:AuthenticationService, private formBuilder: FormBuilder) {
    
   }
   
   

  pickerModes:  {
    single: true, // disable/enable single date picker mode
    //multi: true, // disable/enable multiple date picker mode
    range: true // disable/enable range date picker mode
  }
  
  getDate(event) {
    console.log(event); // logs the picked date data
  }
  ngOnInit() {
    this.registerForm1= this.formBuilder.group({
      date: ['', Validators.required],
      count: ['', Validators.required],
      reason: ['', Validators.required],
      desc: ['', Validators.required],

     
    });
  }

 
 addleave()
  {
    
    //this.leave.fromDate=(string)this.select.begin.toDate();
    this.leave.date1=this.datepipe.transform(this.select.begin.date() ,'yyyy-MM-dd');
    this.leave.date2=this.datepipe.transform(this.select.end.date() ,'yyyy-MM-dd');
       console.log(this.leave.date1+' '+this.leave.date2+ ' '+this.leave.count);
    
    
      console.log(this.leave)
       this.leaveService.addleave(this.leave);

    alert('Leave applied success')
  }
   

  onSubmit() {
    console.log("this.registerForm1");
    console.log(this.registerForm1.status)
    if (this.registerForm1.invalid == true) {
      console.log("inavalid")
      return;
    } else
      if (this.registerForm1.controls) {
        var form = this.registerForm1.controls;
        
        this.leave.date1 = form.date1.value;
        this.leave.Reason = form.reason.value;
        this.leave.count = form.count.value;
        this.leave.comment = form.desc.value;
        console.log("sessionStorage.getItem('userId');" + this.authService.userId)
        
        this.leave.UserId =+ this.authService.userId;
        
        if (this.leave) {
          console.log("this.attend")
          console.log(this.leave)
          this.submitted = true;
          this.leaveService.addleave(this.leave)
            .subscribe(data => {
              console.log("attend data")
              console.log(data)});

          alert(' leave Fillup Successfully ...!');
          this.registerForm1.reset();
        }
        // console.log(this.registerForm);
      }
  }
}
