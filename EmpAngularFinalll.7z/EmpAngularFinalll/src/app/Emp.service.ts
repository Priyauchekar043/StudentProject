import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Emp } from './model/Emp';
import {Router} from "@angular/router";

@Injectable({
  providedIn: 'root'
})
export class EmpService {

  private baseUrl = 'http://localhost:8080/api/student';
  newId;

  constructor(private http:HttpClient,private router: Router,) { }

   sendData(data){
    console.log("inside emp data=>",data);
   this.newId = data;
   }
  
  signUp(emp: Emp): Observable<Object>{
    return this.http.post(`${this.baseUrl}` + `/create`, emp);
  }

   addAdmin(admin : Emp):Observable<Object>{
     return this.http.post(`${this.baseUrl}` + `/addAdmin`, admin);
   }

  viewProfile(): Observable<Object>{
   return this.http.get(`${this.baseUrl}`+`/emps/`+this.newId);
   }

  getAdminList(){
    return this.http.get<Emp[]>(`${this.baseUrl}`+`/getAdminList`);
   }

   getEmpList(){
     return this.http.get<Emp[]>(`${this.baseUrl}`+`/getEmpList`);
   }

   getEmpDetail(userId:number){
   return this.http.get<Emp>(`${this.baseUrl}`+`/getEmpDetail/`+userId);
   }
  
   editStuProfile(email,userId){
  let params = new HttpParams();
    params = params.set('email', email);
   params = params.set('userId', userId);
    return this.http.get(`${this.baseUrl}` + `/update`, { params: params });
   }

   editUser(emp: Emp): void {
    localStorage.removeItem("editUserId");
    localStorage.setItem("editUserId", emp.userId.toString());
    this.router.navigate(['update']);
  };

  // deleteAdmin(studentid:number){
  //   return this.http.delete(`${this.baseUrl}`+`/deleteAdmin/`+studentid);
  // }

  remove(userId:number){
    return this.http.delete(`${this.baseUrl}`+`/deleteEmp/`+userId);
  }
  
}
