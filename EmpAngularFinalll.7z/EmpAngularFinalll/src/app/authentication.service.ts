import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, BehaviorSubject, from } from 'rxjs';
import{ Emp} from'./model/Emp';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  public userId = '';
  private baseUrl = 'http://localhost:8080/api/student';
 private empDetails = new BehaviorSubject(null);
 // private  empDetails : Subject<Object> = new ReplaySubject<Object>(1);
  constructor(private http: HttpClient) { }

  login(username, password): Observable<any> {
    let params = new HttpParams();
    params = params.set('username', username);
    params = params.set('password', password);
    return this.http.get(`${this.baseUrl}` + `/find`, { params: params });
  }

  sendEmpDetail(data) {
    //console.log("admin details")
    this.empDetails.next(data);
    //console.log(this.empDetails);
  }

  getEmpDetail() {
    return this.empDetails.asObservable();
  }
}
