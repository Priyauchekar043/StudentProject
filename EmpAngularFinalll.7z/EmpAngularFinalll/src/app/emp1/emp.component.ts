import { Component, OnInit } from '@angular/core';
import { EmpService } from '../Emp.service';
import { Emp } from '../model/Emp';
import { Router } from '@angular/router';

@Component({
  selector: 'app-emp',
  templateUrl: './emp.component.html',
  styleUrls: ['./emp.component.css']
})
export class EmpComponent implements OnInit {

  emp : any = new Emp();
  constructor(private empService : EmpService, private route: Router) {
    
  }

  ngOnInit() {
    this.empService.viewProfile().subscribe(data => {
    this.emp = data;
    })
  }

   goToViewProfile(){
    debugger
    this.route.navigate(['viewProfile'],this.emp);
   }

}
