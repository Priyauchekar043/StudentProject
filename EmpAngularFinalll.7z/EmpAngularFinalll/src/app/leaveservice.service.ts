import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Leave } from './model/leave';
import {Router} from "@angular/router";
import { ApplyleaveComponent } from './applyleave/applyleave.component';

@Injectable({
  providedIn: 'root'
})
export class LeaveserviceService {

  private baseUrl = 'http://localhost:8080/api/student';
  newId;

  constructor(private http:HttpClient,private router: Router,) { }

   sendData(data){
    console.log("inside attendance data=>",data);
   this.newId = data;
   }
  
   addleave(leave: Leave): Observable<Object>{
    return this.http.post(`${this.baseUrl}` + `/saveleave`, leave);
  }

 
  
  
  getAllAttendance(){
    return this.http.get<Leave[]>(`${this.baseUrl}`+`/getAllleave`);
  }
  //  getEmpDetail(userId:number){
  //  return this.http.get<Emp>(`${this.baseUrl}`+`/getEmpDetail/`+userId);
  //  }
  
  //  editStuProfile(email,userId){
  // let params = new HttpParams();
  //   params = params.set('email', email);
  //  params = params.set('userId', userId);
  //   return this.http.get(`${this.baseUrl}` + `/update`, { params: params });
  //  }

  //  editUser(emp: Emp): void {
  //   localStorage.removeItem("editUserId");
  //   localStorage.setItem("editUserId", emp.userId.toString());
  //   this.router.navigate(['update']);
  // };
 

 
  
}
