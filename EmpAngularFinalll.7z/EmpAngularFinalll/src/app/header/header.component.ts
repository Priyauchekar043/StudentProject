import { Component, OnInit, Input, Output,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { EventEmitter } from 'events';
import { AuthenticationService } from '../authentication.service';
import { Emp } from '../model/Emp';
import { EmpService } from '../Emp.service';
import{AttendService} from '../attend.service';

import { Attendance } from '../model/attendance';
import { AttendanceComponent } from '../attendance/attendance.component';
import { LeavelistComponent } from '../leavelist/leavelist.component';
import { Leave } from '../model/leave';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  @Input() name: string;
  @Output() changeName = new EventEmitter();
  public Role;
  emp: Emp;
  
  userId: number;
  empList: Emp[];
  attendance:Attendance[];
 
  showEmp: boolean = false;
  showEmpList: boolean = false;
  editEmp: boolean = false;
  //showDeleteStudentFlag: boolean = false;
  attendList: Attendance[];
  showAdmin: boolean;
  adminList: Emp[];
  addNewAdminFlag: boolean = false;
  showAttendanceEmp:boolean=false;
  addAttendance:boolean=false;
  public leaveList: Leave[];
  showLeave: boolean
  addLeave: boolean;

  constructor(private authService: AuthenticationService, private empService: EmpService,private attendService:AttendService) {
    this.authService.getEmpDetail().subscribe(data => {
      if (data.role == 'Emp') {
        this.Role = data.role;
        this.emp = data;
        this.userId = data.userId;
       //  this.authService.sendEmpDetail(data);
      }
      if (data.role == 'Admin') {
        this.Role = data.role;
        this.emp = data;
        //this.authService.sendEmpDetail(data);
      }
      if (data.role == 'Adminstaff') {
        this.Role = data.role;
        this.emp = data;
        //this.authService.sendEmpDetail(data);
      }
      //console.log(data);
    });
  }

  //Superadmin module
  getAdminList() {
    this.empService.getAdminList().subscribe(data => {
      this.adminList = data;
      this.showAdmin = true;
      this.showAttendanceEmp = false;
      this.addNewAdminFlag = false;
      this.showLeave = false;
     
   });
 }

 showAttendanceForEmp() {
  
  this.attendService.getAllAttendance().subscribe(data => {
   this.attendList = data;
   this.showAttendanceEmp = true;
    this.showAdmin = false;
    this.showLeave = false;
   
 })
 }

  
  // //admin module
  getEmpList() {
    debugger
    this.empService.getEmpList().subscribe(data => {
      this.empList = data;
      this.showEmpList = true;
      this.editEmp= false;
 
     })
   }

  // showDeleteStudentPage() {
  //   this.showDeleteStudentFlag = true;
  //   this.showStudentList = false;
  //   this.addActivity = false;
  //   this.showActivityFlagAdmin = false;
  // }



  // showActivitiesForAdmin() {
  //   debugger
  //   this.activityService.getAllActivities().subscribe(data => {
  //     this.activityList = data;
  //     this.showActivityFlagAdmin = true;
  //     this.addActivity = false;
  //     this.showDeleteStudentFlag = false;
  //     this.showStudentList = false;
  //   })
  // }

 // Student module
  getEmpDetail(id: number) {
     this.empService.getEmpDetail(id).subscribe(data => {
      this.showEmp = true;
     //this.editStudent = false;
     this.emp = data;
    this.showAttendanceEmp = true;
    this.addAttendance=false;
    this.addLeave=false;
   })
 }

 getEmpDetailforEdit(id: number) {
    this.empService.getEmpDetail(id).subscribe(data => {
      this.showEmpList = false;
     this.emp = data;
     this.editEmp = true;
  //     this.showActivityFlagStu = false;
    })
 }


 getAttendance() {
  this.addAttendance=true;
  this.showEmp = false;
  this.addLeave=false;
 }

 applyLeave() {
  this.addLeave=true;
  this.addAttendance=false;
  this.showEmp = false;
 }
 
 displayLeave() {
this.showLeave = true;
this.showAdmin =false;
this.showAttendanceEmp=false;

 }



  ngOnInit() {

  }
}
