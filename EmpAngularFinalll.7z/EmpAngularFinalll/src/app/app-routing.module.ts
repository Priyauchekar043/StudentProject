import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { AdminComponent } from './admin/admin.component';
import { EmpComponent } from './Emp/Emp.component';
import {AdminstaffComponent } from './adminstaff/adminstaff.component'
import { ViewProfileComponent} from './view-profile/view-profile.component';
import { EditempComponent } from './editemp/editemp.component';
import { AttendanceComponent } from './attendance/attendance.component';
import { ApplyleaveComponent } from './applyleave/applyleave.component';

const routes: Routes = [
  { path: '', component: WelcomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'signUp', component: SignupComponent },
  { path: 'emps', component: EmpComponent },
 { path: 'admin', component: AdminComponent },
  { path: 'adminstaff', component: AdminstaffComponent },
  { path: 'emps/viewProfile', component: ViewProfileComponent },
{path: 'editemp', component: EditempComponent},
{path: 'leave', component: ApplyleaveComponent},
{path: 'attendance', component: AttendanceComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
