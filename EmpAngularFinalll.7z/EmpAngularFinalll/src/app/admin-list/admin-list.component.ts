import { Component, OnInit,Input } from '@angular/core';
import { EmpService } from '../Emp.service';
import { Emp } from '../model/Emp';

@Component({
  selector: 'app-admin-list',
  templateUrl: './admin-list.component.html',
  styleUrls: ['./admin-list.component.css']
})
export class AdminListComponent implements OnInit {

  @Input() adminList: Emp[];
  searchText;
  constructor(private empService: EmpService) { }

  ngOnInit() {
  }

}
