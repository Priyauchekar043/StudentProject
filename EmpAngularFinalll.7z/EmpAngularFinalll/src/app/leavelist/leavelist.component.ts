import { Component, OnInit, Input} from '@angular/core';
import { Leave } from '../model/leave';
import { LeaveserviceService } from '../leaveservice.service';

@Component({
  selector: 'app-leavelist',
  templateUrl: './leavelist.component.html',
  styleUrls: ['./leavelist.component.css']
})
export class LeavelistComponent implements OnInit {
  @Input() leaveList: Leave[];
  constructor(private leaveService:LeaveserviceService
  ) { }

  ngOnInit() {
  }

}
