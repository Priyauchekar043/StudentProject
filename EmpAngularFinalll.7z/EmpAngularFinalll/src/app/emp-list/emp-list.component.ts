import { Component, OnInit,Input } from '@angular/core';
import { EmpService } from '../Emp.service';
import { Emp } from '../model/Emp';
import {Router, NavigationExtras} from "@angular/router";


@Component({
  selector: 'app-emp-list',
  templateUrl: './emp-list.component.html',
  styleUrls: ['./emp-list.component.css']
})
export class EmpListComponent implements OnInit {
  @Input() empList: Emp[];
  emp : Emp;
  searchText;
  
  constructor(private empService: EmpService, private router : Router) { }

  ngOnInit() {
  }

  remove(id:number){
    this.empService.remove(id).subscribe(response=>{
      this.empService.getEmpList().subscribe(resp=>{
        this.empList=resp;
      }); 
    });
   
    
  }

  // edit(id:number){
  //   this.empService.getEmpDetail(id).subscribe(response=>{
  //     this.emp = response;
  //     //  console.log(this.emp);
  //     let navigationExtras: NavigationExtras = {
  //       queryParams: {
  //           "emp": this.emp
  //       }
  //   };
  //     this.router.navigate(['editemp',navigationExtras]);
      
  //   });
   
    
  // }

}
