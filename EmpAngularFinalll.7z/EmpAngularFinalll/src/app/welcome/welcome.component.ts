import { Component, OnInit,Input,EventEmitter,Output } from '@angular/core';
import { AuthenticationService } from '../authentication.service';
import { Emp } from '../model/Emp';
import { EmpService } from '../Emp.service';
@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {
  title = 'Employee Attendance Monitoring System';

  @Input() name: string;
  @Output() changeName = new EventEmitter();
  public Role;
  welcomePage = true;
  emp: Emp;
  showAdmin: boolean;
  adminList: Emp[];
  addNewAdminFlag: boolean = false;
  constructor(private authService: AuthenticationService, private empService: EmpService) { }
  addNewAdmin() {
    this.addNewAdminFlag = true;
     this.showAdmin = false;
     this.welcomePage = false;
     //this.showDeleteAdminFlag = false;
   }
  ngOnInit() {
  }

}
