import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminstaff',
  templateUrl: './adminstaff.component.html',
  styleUrls: ['./adminstaff.component.css']
})
export class AdminstaffComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
