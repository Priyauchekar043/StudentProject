export class Leave {

     leaveId:number;
	 date1:String;
	 date2:String;
	totalleave:number;
	count:number;
	 reaminleave:number;
	 Reason:number;
	 comment:String;
	 UserId:number;

}
