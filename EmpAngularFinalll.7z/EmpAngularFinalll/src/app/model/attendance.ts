export class Attendance {

    aId:number;
    date:String;
    attenddays:number;
    empleave:number;
    totalattenddays:number;
    salary:number;
    userId:number;

}
