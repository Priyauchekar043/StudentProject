export class Emp {
    userId: number;
    name: String;
    lastname: String;
    address: String;
    email: String;
    phone: String;
    username: String;
    password: String;
    role: String;
   


    










}
