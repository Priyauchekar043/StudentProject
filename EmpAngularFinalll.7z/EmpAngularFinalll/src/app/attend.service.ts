import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Attendance } from './model/attendance';
import {Router} from "@angular/router";
import { AttendanceComponent } from './attendance/attendance.component';

@Injectable({
  providedIn: 'root'
})
export class AttendService {

  private baseUrl = 'http://localhost:8080/api/student';
  newId;

  constructor(private http:HttpClient,private router: Router,) { }

   sendData(data){
    console.log("inside attendance data=>",data);
   this.newId = data;
   }
  
   attendform(attendance: Attendance): Observable<Object>{
    return this.http.post(`${this.baseUrl}` + `/save`, attendance);
  }

 
  
  
  getAllAttendance(){
    return this.http.get<Attendance[]>(`${this.baseUrl}`+`/getAll`);
  }
  //  getEmpDetail(userId:number){
  //  return this.http.get<Emp>(`${this.baseUrl}`+`/getEmpDetail/`+userId);
  //  }
  
  //  editStuProfile(email,userId){
  // let params = new HttpParams();
  //   params = params.set('email', email);
  //  params = params.set('userId', userId);
  //   return this.http.get(`${this.baseUrl}` + `/update`, { params: params });
  //  }

  //  editUser(emp: Emp): void {
  //   localStorage.removeItem("editUserId");
  //   localStorage.setItem("editUserId", emp.userId.toString());
  //   this.router.navigate(['update']);
  // };
 

 
  
}
