import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Emp } from '../model/Emp';
import { AuthenticationService } from '../authentication.service';
import { Router } from "@angular/router";
import { EmpService } from '../Emp.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  invalidLogin: boolean = false;
  loginForm: FormGroup;

  emp: Emp = new Emp();
  constructor(private formBuilder: FormBuilder, private router: Router, private authService: AuthenticationService, private empService: EmpService) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  onSubmit() {
   // console.log(this.loginForm)
    if (this.loginForm.invalid == true) {
     console.log("invalid")
      return;
    }
    this.authService.login(this.loginForm.controls.username.value, this.loginForm.controls.password.value)
      .subscribe(response => {
        console.log(response.userId);
        this.authService.userId = response.userId;
        if (response) {
          if (response.role == 'Emp') {
            // this.studentService.sendData(response);
            
            this.authService.sendEmpDetail(response);
            this.router.navigate(['/emps']);

          } else
            if (response.role == 'Admin') {
              
              this.authService.sendEmpDetail(response);
              this.router.navigate(['/admin']);
            } else
              if (response.role == 'Adminstaff') {
                this.router.navigate(['/adminstaff']);
                this.authService.sendEmpDetail(response);
              }
        }
        else {
          alert('wrong user');
          this.loginForm.reset();
        }
      });
  }


}



