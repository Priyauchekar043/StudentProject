import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Attendance } from '../model/attendance';
import { Router } from "@angular/router";
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker/public_api';
import {AttendService} from '../attend.service';
import { AuthenticationService } from '../authentication.service';
@Component({
  selector: 'app-attendance',
  templateUrl: './attendance.component.html',
  styleUrls: ['./attendance.component.css']
})
export class AttendanceComponent implements OnInit {

  registerForm1: FormGroup;
  attend: Attendance = new Attendance();
  submitted = false;
  datePickerConfig: Partial<BsDatepickerConfig>;
  constructor(private formBuilder: FormBuilder,
    private router: Router, 
    private AttendService: AttendService, private authService: AuthenticationService) {
      this.datePickerConfig = Object.assign({},
        {
          containerClass: 'theme-dark-blue',
          maxDate : new Date()
        });
     }

    ngOnInit() {
      this.registerForm1= this.formBuilder.group({
        attenddays: ['', Validators.required],
        totalattenddays: ['', Validators.required],
        date: ['', Validators.required],

       
      });
    }
    onSubmit() {
      console.log("this.registerForm1");
      console.log(this.registerForm1.status)
      if (this.registerForm1.invalid == true) {
        console.log("inavalid")
        return;
      } else
        if (this.registerForm1.controls) {
          var form = this.registerForm1.controls;
          
          this.attend.attenddays = form.attenddays.value;
          this.attend.totalattenddays = form.totalattenddays.value;
          this.attend.date = form.date.value;
          console.log("sessionStorage.getItem('userId');" + this.authService.userId)
          
          this.attend.userId =+ this.authService.userId;
          
          if (this.attend) {
            console.log("this.attend")
            console.log(this.attend)
            this.submitted = true;
            this.AttendService.attendform(this.attend)
              .subscribe(data => {
                console.log("attend data")
                console.log(data)});
  
            alert(' Attendance Fillup Successfully ...!');
            this.registerForm1.reset();
          }
          // console.log(this.registerForm);
        }
    }

}
