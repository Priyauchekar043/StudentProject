import { Component, OnInit,Input } from '@angular/core';
import { Emp } from '../model/Emp';

import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { EmpService } from '../Emp.service';
import { Response } from 'selenium-webdriver/http';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-editemp',
  templateUrl: './editemp.component.html',
  styleUrls: ['./editemp.component.css']
})
export class EditempComponent implements OnInit {

  @Input() emp: Emp;
  xyz: boolean = false;
  editStuForm: FormGroup;
  empId: Emp;
  constructor(private formBuilder: FormBuilder,
    private empService: EmpService,  private route: ActivatedRoute) { }

  ngOnInit() {
    this.editStuForm = this.formBuilder.group({
      name: ['', [Validators.required,
        Validators.maxLength(50),
        Validators.pattern('^[a-zA-Z ]*$')]],
      lastname: ['', [Validators.required,
        Validators.maxLength(50),
        Validators.pattern('^[a-zA-Z ]*$')]],
        email: ['', [Validators.required, Validators.email,Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      phone: ['', [Validators.required, Validators.maxLength(10), Validators.pattern('^[0-9]*$') ]],
      address: ['', Validators.required],
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]]
      
    });
    this.route.queryParams.subscribe(params => {
      this.empId = params["emp"]; 
      console.log("ID:")
  console.log(this.empId)
  });
   
  
  }

  // onSubmit() {
  //   console.log(this.editStuForm);
  //   if (this.editStuForm.invalid) {
  //     console.log("Invalid");
  //     return;
  //   } else {
  //     this.emp.email = this.editStuForm.controls.email.value;
  //   }

  //   if (this.emp.email) {
  //     console.log(this.emp.userId);
  //     this.empService.editStuProfile(this.emp.email, this.emp.userId)
  //       .subscribe(response => {
  //         console.log(response);
  //         this.xyz = true;
  //       });
  //   }
  // }

  
}