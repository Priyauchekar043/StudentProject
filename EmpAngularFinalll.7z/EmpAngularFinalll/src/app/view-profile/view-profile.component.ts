import { Component, OnInit ,Input} from '@angular/core';
import { Emp } from '../model/Emp';
import { EmpService } from '../Emp.service';

@Component({
  selector: 'app-view-profile',
  templateUrl: './view-profile.component.html',
  styleUrls: ['./view-profile.component.css']
})
export class ViewProfileComponent implements OnInit {

 
  @Input() emp: Emp;
  constructor(private empService: EmpService) { }
  ngOnInit() {
  }

}
